"""
whatsapp.py
Handles all WhatsApp communication via Twilio:
  - Sending draft posts for approval
  - Parsing user replies (YES / EDIT / REDO / NO)
  - Sending engagement reminders after posting
  - Sending weekly analytics summary
"""

from twilio.rest import Client
from datetime import datetime
import config

client = Client(config.TWILIO_ACCOUNT_SID, config.TWILIO_AUTH_TOKEN)


# ─────────────────────────────────────────────────────────────
# Send Functions
# ─────────────────────────────────────────────────────────────

def send_message(body: str) -> bool:
    """Send a plain WhatsApp message to Jayesh."""
    try:
        msg = client.messages.create(
            from_=config.TWILIO_WHATSAPP_FROM,
            to=config.TWILIO_WHATSAPP_TO,
            body=body,
        )
        print(f"[WhatsApp] Sent: {msg.sid}")
        return True
    except Exception as e:
        print(f"[WhatsApp] Send error: {e}")
        return False


def send_draft_for_approval(post_id: int, post: dict) -> bool:
    """
    Send a post draft to Jayesh's WhatsApp for approval.
    Format: clean, easy to read on mobile.
    """
    pillar_emoji = {
        "regulatory":     "📋",
        "rca_fmea":       "🔍",
        "lean_excellence":"⚙️",
        "pmo_genai":      "🤖",
        "any":            "💡",
    }
    fmt_label = {
        "news_insight":   "News + Insight",
        "did_you_know":   "Did You Know?",
        "dmaic_case":     "DMAIC Case",
        "poll":           "Poll",
        "personal_story": "Personal Story",
        "rca_tip":        "RCA Tip",
    }

    emoji = pillar_emoji.get(post.get("pillar", ""), "📝")
    fmt   = fmt_label.get(post.get("format", ""), "Post")
    now   = datetime.now().strftime("%a, %d %b — %I:%M %p IST")

    message = f"""
{emoji} *LINKEDIN DRAFT #{post_id}*
📅 {now}
🏷 Format: {fmt}

─────────────────────
{post['post_text']}
─────────────────────

Reply with:
✅ *YES* — Post it now
✏️ *EDIT [your changes]* — e.g. "EDIT make it shorter"
🔄 *REDO* — Regenerate completely
❌ *NO* — Skip today
""".strip()

    return send_message(message)


def send_engagement_reminder(post_id: int) -> bool:
    """Send reminder 30 min after posting to engage with the post."""
    message = f"""
🔔 *ENGAGEMENT REMINDER*

Your LinkedIn post #{post_id} has been live for 30 minutes!

👉 *Go like and comment on your own post now.*

This signals LinkedIn's algorithm that the post is engaging — it will show it to more people.

Open LinkedIn → Your post → Like it + leave a comment like:
_"Happy to discuss this further — drop your thoughts below!"_

This small action can 3x your reach. 🚀
""".strip()
    return send_message(message)


def send_weekly_summary(stats: dict) -> bool:
    """Send weekly analytics summary every Sunday."""
    week_start = stats.get("week_start", "this week")
    message = f"""
📊 *WEEKLY LINKEDIN SUMMARY*
Week of {week_start}

Posts Generated:  {stats.get('posts_generated', 0)}
✅ Posted:        {stats.get('posts_posted', 0)}
❌ Rejected:      {stats.get('posts_rejected', 0)}
⏭ Skipped:       {stats.get('posts_skipped', 0)}

💡 *Tip for next week:*
{_weekly_tip(stats)}

Keep showing up consistently — LinkedIn rewards regularity! 💪
""".strip()
    return send_message(message)


def send_token_expiry_reminder() -> bool:
    """Remind to refresh LinkedIn token before 60-day expiry."""
    return send_message(
        "⚠️ *LINKEDIN TOKEN REMINDER*\n\n"
        "Your LinkedIn access token expires in 7 days.\n"
        "Run: python get_linkedin_token.py\n"
        "to refresh it before it expires."
    )


def send_error_alert(error_msg: str) -> bool:
    """Alert when something goes wrong."""
    return send_message(
        f"🚨 *AGENT ERROR*\n\n{error_msg}\n\nPlease check the logs."
    )


def _weekly_tip(stats: dict) -> str:
    posted = stats.get("posts_posted", 0)
    if posted == 0:
        return "Try to approve at least 3 posts next week for best results."
    elif posted <= 2:
        return "3-4 posts per week is the sweet spot for LinkedIn growth."
    elif posted >= 4:
        return "Great consistency! Focus on engaging with comments on your posts."
    return "Steady posting builds authority. Keep it up!"


# ─────────────────────────────────────────────────────────────
# Reply Parser
# ─────────────────────────────────────────────────────────────

def parse_reply(reply_text: str) -> dict:
    """
    Parses Jayesh's WhatsApp reply into a structured action.

    Returns:
    {
        "action": "approve" | "edit" | "redo" | "skip" | "unknown",
        "feedback": str  (for edit/redo)
    }
    """
    text = reply_text.strip().upper()

    # YES variants
    if text in ("YES", "Y", "YES.", "YEP", "YA", "HAAN", "OK", "OKAY", "POST IT", "POST"):
        return {"action": "approve", "feedback": ""}

    # NO / SKIP variants
    if text in ("NO", "N", "SKIP", "NAH", "NAHI", "CANCEL", "PASS"):
        return {"action": "skip", "feedback": ""}

    # REDO variants
    if text in ("REDO", "REGENERATE", "AGAIN", "RETRY", "NEW", "REWRITE"):
        return {"action": "redo", "feedback": ""}

    # EDIT with feedback
    original = reply_text.strip()
    if original.upper().startswith("EDIT"):
        feedback = original[4:].strip().lstrip(":").strip()
        return {"action": "edit", "feedback": feedback}

    # REDO with feedback
    if original.upper().startswith("REDO"):
        feedback = original[4:].strip().lstrip(":").strip()
        return {"action": "redo", "feedback": feedback}

    # Check for partial YES
    if any(word in text for word in ["YES", "APPROVE", "POST", "GO", "LOOKS GOOD", "PERFECT", "GOOD"]):
        return {"action": "approve", "feedback": ""}

    # Check for partial NO
    if any(word in text for word in ["NO", "SKIP", "DONT", "DON'T", "CANCEL"]):
        return {"action": "skip", "feedback": ""}

    # Unknown — send back to user
    return {"action": "unknown", "feedback": original}


if __name__ == "__main__":
    # Quick test
    result = send_message("✅ LinkedIn Agent is connected and ready, Jayesh!")
    print("Message sent:", result)
